Place the aligned MMSA files (https://github.com/thuiar/MMSA) here:

    datasets/MOSI/aligned_50.pkl
    datasets/MOSEI/aligned_50.pkl

Audio, visual features and labels are read from these files; the text of each sample is replaced by the
utterance-level features in `text_features/` (matched by sample id).
