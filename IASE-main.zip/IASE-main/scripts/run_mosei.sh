#!/usr/bin/env bash
# IASE on CMU-MOSEI, complete data: pre-training + fine-tuning with seeds 0, 1, 2.
# Run from the repository root:  bash scripts/run_mosei.sh
set -e
python run.py mosei --seeds 0 1 2
