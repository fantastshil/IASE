@echo off
rem IASE on CMU-MOSI, complete data: pre-training + fine-tuning with seeds 0, 1, 2.
rem Run from the repository root:  scripts\run_mosi.bat
python run.py mosi --seeds 0 1 2 || exit /b 1
