@echo off
rem IASE on CMU-MOSEI, complete data: pre-training + fine-tuning with seeds 0, 1, 2.
rem Run from the repository root:  scripts\run_mosei.bat
python run.py mosei --seeds 0 1 2 || exit /b 1
