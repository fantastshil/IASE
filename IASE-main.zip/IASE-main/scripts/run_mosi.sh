#!/usr/bin/env bash
# IASE on CMU-MOSI, complete data: pre-training + fine-tuning with seeds 0, 1, 2.
# Run from the repository root:  bash scripts/run_mosi.sh
set -e
python run.py mosi --seeds 0 1 2
