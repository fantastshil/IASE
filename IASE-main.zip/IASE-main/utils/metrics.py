# -*- coding: utf-8 -*-
import numpy as np


def weighted_f1(y_true, y_pred, classes):
    total = 0.0
    for c in classes:
        tp = np.sum((y_pred == c) & (y_true == c))
        fp = np.sum((y_pred == c) & (y_true != c))
        fn = np.sum((y_pred != c) & (y_true == c))
        prec = tp / (tp + fp) if tp + fp > 0 else 0.0
        rec = tp / (tp + fn) if tp + fn > 0 else 0.0
        f1 = 2 * prec * rec / (prec + rec) if prec + rec > 0 else 0.0
        total += f1 * np.sum(y_true == c)
    return total / len(y_true)


def sign_classes(pred, band):
    c = np.ones(pred.shape, dtype=np.int64)
    c[pred < -band] = 0
    c[pred > band] = 2
    return c


def msa_metrics(pred, y_reg, y_cls, neutral_band=0.5):
    pred = np.asarray(pred, dtype=np.float64).reshape(-1)
    y_reg = np.asarray(y_reg, dtype=np.float64).reshape(-1)
    y_cls = np.asarray(y_cls).reshape(-1)
    out = {}

    p_sign = sign_classes(pred, neutral_band)
    out['sign_acc3'] = float(np.mean(p_sign == y_cls))
    out['sign_f1'] = float(weighted_f1(y_cls, p_sign, [0, 1, 2]))

    t_mmsa = np.round(np.clip(y_reg, -1., 1.)).astype(np.int64) + 1
    p_mmsa = np.round(np.clip(pred, -1., 1.)).astype(np.int64) + 1
    out['mmsa_acc3'] = float(np.mean(p_mmsa == t_mmsa))
    out['mmsa_f1'] = float(weighted_f1(t_mmsa, p_mmsa, [0, 1, 2]))

    t2, p2 = (y_reg >= 0).astype(np.int64), (pred >= 0).astype(np.int64)
    out['has0_acc2'] = float(np.mean(p2 == t2))
    out['has0_f1'] = float(weighted_f1(t2, p2, [0, 1]))
    nz = y_reg != 0
    if nz.any():
        t2n, p2n = (y_reg[nz] > 0).astype(np.int64), (pred[nz] > 0).astype(np.int64)
        out['acc2_non0'] = float(np.mean(p2n == t2n))
        out['non0_f1'] = float(weighted_f1(t2n, p2n, [0, 1]))
    else:
        out['acc2_non0'] = out['non0_f1'] = float('nan')
    out['mae'] = float(np.mean(np.abs(pred - y_reg)))
    out['corr'] = float(np.corrcoef(pred, y_reg)[0, 1]) if np.std(pred) > 0 else 0.0
    return out


LOWER_IS_BETTER = {'mae'}
