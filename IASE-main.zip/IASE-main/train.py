# -*- coding: utf-8 -*-

import os
import sys

import numpy as np
import torch

from msa.msa_args import parse_args
from msa.msa_data import load_msa_data
from pretrain import get_device
from training.finetune import train_iase


def main():
    args = parse_args()
    if args.pretrain_path is None:
        args.pretrain_path = './runs/{}/pretrain/model.pt'.format(args.domain)
    print(args)
    device = get_device()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    data = load_msa_data(args)

    log_dir = args.log_dir or 'train_r{}_seed{}'.format(args.missing_rate, args.seed)
    log_path = './runs/{}/{}/'.format(args.domain, log_dir)
    os.makedirs(log_path, exist_ok=True)
    with open(os.path.join(log_path, 'cmd_input.txt'), 'a') as f:
        f.write('python ' + ' '.join(sys.argv) + '\n')
    train_iase(data, args, log_path, device)


if __name__ == '__main__':
    main()
