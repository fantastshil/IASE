# -*- coding: utf-8 -*-
import os
import sys

import numpy as np
import torch

from msa.msa_args import parse_args
from msa.msa_data import load_msa_data
from pretraining.pretrain_iam import pretrain_iam
from utils.utils import auto_select_gpu


def get_device():
    if torch.cuda.is_available():
        try:
            cuda = auto_select_gpu()
        except Exception:
            cuda = 0
        print('Using GPU {}'.format(cuda))
        return torch.device('cuda:{}'.format(cuda))
    print('Using CPU')
    return torch.device('cpu')


def main():
    args = parse_args()
    print(args)
    device = get_device()
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    data = load_msa_data(args, missing_rate=0.0)

    log_path = './runs/{}/{}/'.format(args.domain, args.log_dir or 'pretrain')
    os.makedirs(log_path, exist_ok=True)
    with open(os.path.join(log_path, 'cmd_input.txt'), 'a') as f:
        f.write('python ' + ' '.join(sys.argv) + '\n')
    pretrain_iam(data, args, log_path, device)


if __name__ == '__main__':
    main()
