# -*- coding: utf-8 -*-

import argparse
import pickle
import shlex
import subprocess
import sys

import numpy as np


def run(cmd):
    print('>>', ' '.join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('domain', choices=['mosi', 'mosei'])
    p.add_argument('--seeds', type=int, nargs='+', default=[0, 1, 2])
    p.add_argument('--skip_pretrain', action='store_true')
    p.add_argument('--extra', type=str, default='', help='extra options for pretrain.py and train.py, e.g. "--contrast_batch 4096"')
    a = p.parse_args()
    extra = shlex.split(a.extra)

    if not a.skip_pretrain:
        run([sys.executable, 'pretrain.py', '--log_dir', 'pretrain'] + extra + [a.domain])

    res = []
    for s in a.seeds:
        log_dir = 'full_seed{}'.format(s)
        run([sys.executable, 'train.py', '--seed', str(s), '--log_dir', log_dir,
             '--pretrain_path', './runs/{}/pretrain/model.pt'.format(a.domain)] + extra + [a.domain])
        with open('./runs/{}/{}/result.pkl'.format(a.domain, log_dir), 'rb') as f:
            res.append(pickle.load(f)['best_test'])

    def ms(k, percent=True):
        v = np.array([m[k] for m in res]) * (100 if percent else 1)
        sd = v.std(ddof=1) if len(v) > 1 else 0.0
        return ('{:.2f} +- {:.2f}' if percent else '{:.3f} +- {:.3f}').format(v.mean(), sd)

    print('\n{} test results, complete data, {} seed(s), epoch picked by validation Non0 Acc-2'.format(a.domain.upper(), len(res)))
    print('  Non0 Acc-2 {} | Non0 F1 {}'.format(ms('acc2_non0'), ms('non0_f1')))
    print('  Has0 Acc-2 {} | Has0 F1 {}'.format(ms('has0_acc2'), ms('has0_f1')))
    print('  MAE {} | Corr {}'.format(ms('mae', False), ms('corr', False)))


if __name__ == '__main__':
    main()
