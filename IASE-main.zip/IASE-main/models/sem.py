# -*- coding: utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.prediction_model import MLPNet


class SentimentEnhanceModule(nn.Module):
    def __init__(self, in_dim, hidden_dim=32, out_dim=32, tau=0.3, normalize=True, dropout=0.):
        super(SentimentEnhanceModule, self).__init__()
        hidden = [hidden_dim] if hidden_dim and hidden_dim > 0 else []
        self.mlp = MLPNet(in_dim, out_dim, hidden_layer_sizes=hidden, hidden_activation='relu', dropout=dropout)
        self.tau = tau
        self.normalize = normalize

    def forward(self, node_embedding, labels):
        z = self.mlp(node_embedding)                         # LS_n
        if self.normalize:
            z = F.normalize(z, p=2, dim=-1)
        logits = torch.einsum('nc,kc->nk', z, z) / self.tau   # lp_n / tau
        n = z.size(0)
        self_mask = torch.eye(n, dtype=torch.bool, device=z.device)
        logits = logits.masked_fill(self_mask, float('-inf'))
        log_prob = F.log_softmax(logits, dim=1)

        pos = (labels.view(-1, 1) == labels.view(1, -1)) & ~self_mask
        n_pos = pos.sum(dim=1)
        has_pos = n_pos > 0
        if not has_pos.any():
            return z.sum() * 0.
        pos_log_prob = log_prob.masked_fill(~pos, 0.).sum(dim=1)
        return -(pos_log_prob[has_pos] / n_pos[has_pos]).mean()
