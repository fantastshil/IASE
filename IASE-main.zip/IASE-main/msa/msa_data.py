# -*- coding: utf-8 -*-
import pickle
import warnings

import numpy as np
import torch
from torch_geometric.data import Data


MODALITIES = ('audio', 'vision', 'text')
SPLITS = ('train', 'valid', 'test')


def create_node(nrow, ncol, mode):
    if mode == 0:
        feature_ind = np.array(range(ncol))
        feature_node = np.zeros((ncol, ncol))
        feature_node[np.arange(ncol), feature_ind] = 1
        sample_node = [[1] * ncol for i in range(nrow)]
        node = sample_node + feature_node.tolist()
    elif mode == 1:
        feature_ind = np.array(range(ncol))
        feature_node = np.zeros((ncol, ncol + 1))
        feature_node[np.arange(ncol), feature_ind + 1] = 1
        sample_node = np.zeros((nrow, ncol + 1))
        sample_node[:, 0] = 1
        node = sample_node.tolist() + feature_node.tolist()
    return node


def create_edge(n_row, n_col):
    edge_start = []
    edge_end = []
    for x in range(n_row):
        edge_start = edge_start + [x] * n_col  # obj
        edge_end = edge_end + list(n_row + np.arange(n_col))  # att
    edge_start_new = edge_start + edge_end
    edge_end_new = edge_end + edge_start
    return (edge_start_new, edge_end_new)



def _masked_mean(x, mask, chunk=1024):
    out = np.empty((x.shape[0], x.shape[2]), dtype=np.float32)
    for i in range(0, x.shape[0], chunk):
        xc = np.nan_to_num(np.asarray(x[i:i + chunk], dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0)
        m = mask[i:i + chunk, :, None].astype(np.float64)
        out[i:i + chunk] = ((xc * m).sum(axis=1) / np.clip(m.sum(axis=1), 1.0, None)).astype(np.float32)
    return out


def pool_split(split, pooling='mask'):
    feats = []
    if pooling == 'mask' and 'text_bert' in split:
        mask = split['text_bert'][:, 1, :]
    else:
        mask = None
    for mod in MODALITIES:
        x = split[mod]
        if x.ndim == 2:
            feats.append(np.nan_to_num(x.astype(np.float32)))
            continue
        if mask is not None and mask.shape[1] == x.shape[1]:
            m = mask
        else:
            if mask is not None:
                warnings.warn('{}: sequence length differs from text mask (unaligned data?); using plain mean'.format(mod))
            m = np.ones(x.shape[:2])
        feats.append(_masked_mean(x, m))
    return feats


def get_labels(split):
    y_reg = np.asarray(split['regression_labels'], dtype=np.float32).reshape(-1)
    if 'classification_labels' in split:
        y_cls = np.asarray(split['classification_labels']).reshape(-1).astype(np.int64)
    else:  # negative [-3,0), neutral [0], positive (0,3]
        y_cls = (np.sign(y_reg) + 1).astype(np.int64)
    return y_reg, y_cls


def make_missing_mask(n_samples, n_modality, rate, seed, min_available=0, keep_mode='swap'):
    rng = np.random.RandomState(seed)
    missing = np.zeros((n_samples, n_modality), dtype=bool)
    k = int(round(rate * n_samples))
    if min_available and keep_mode == 'swap':
        k_max = (n_modality - min_available) * n_samples // n_modality
        if k > k_max:
            warnings.warn('missing rate {} is not possible with min_available={}; capped at {:.3f}'.format(
                rate, min_available, k_max / n_samples))
            k = k_max
    if k > 0:
        for j in range(n_modality):
            missing[rng.choice(n_samples, k, replace=False), j] = True
    if not min_available:
        return missing

    max_missing = n_modality - min_available
    if keep_mode == 'restore':
        for i in np.where(missing.sum(1) > max_missing)[0]:
            drop = rng.choice(np.where(missing[i])[0], missing[i].sum() - max_missing, replace=False)
            missing[i, drop] = False
        return missing
    if keep_mode != 'swap':
        raise ValueError('unknown keep_mode {}'.format(keep_mode))
    for i in np.where(missing.sum(1) > max_missing)[0]:
        for j in rng.permutation(np.where(missing[i])[0]):
            if missing[i].sum() <= max_missing:
                break
            cand = np.where(~missing[:, j] & (missing.sum(1) < max_missing))[0]
            if len(cand) == 0:
                continue
            s = rng.choice(cand)
            missing[i, j] = False
            missing[s, j] = True
    assert (missing.sum(1) <= max_missing).all(), 'could not satisfy min_available'
    return missing


def build_graph(feats, y_reg, y_cls, split_sizes, missing, missing_mode, node_mode=0):
    n_tr, n_va, n_te = split_sizes
    n_samples = n_tr + n_va + n_te
    n_modality = len(MODALITIES)
    input_dims = tuple(int(f.shape[1]) for f in feats)

    feats = [f.copy() for f in feats]
    if missing_mode == 'zero':
        for j in range(n_modality):
            feats[j][missing[:, j]] = 0.0
        keep = np.ones((n_samples, n_modality), dtype=bool)
    elif missing_mode == 'drop':
        keep = ~missing
    else:
        raise ValueError('unknown --missing_mode {}'.format(missing_mode))

    edge_start, edge_end = create_edge(n_samples, n_modality)
    edge_index = torch.tensor([edge_start, edge_end], dtype=torch.long)

    keep_mask = torch.tensor(keep.reshape(-1), dtype=torch.bool)
    double_mask = torch.cat((keep_mask, keep_mask), dim=0)

    attrs = [torch.tensor(np.concatenate([f, f], axis=0), dtype=torch.float) for f in feats]
    edge_audio_attr = attrs[0][double_mask[0::3]]
    edge_visual_attr = attrs[1][double_mask[1::3]]
    edge_text_attr = attrs[2][double_mask[2::3]]

    train_edge_index = torch.cat([edge_index[:, 0::3][:, double_mask[0::3]],
                                  edge_index[:, 1::3][:, double_mask[1::3]],
                                  edge_index[:, 2::3][:, double_mask[2::3]]], dim=1)

    x = torch.tensor(create_node(n_samples, n_modality, node_mode), dtype=torch.float)
    train_y_mask = torch.zeros(n_samples, dtype=torch.bool)
    train_y_mask[:n_tr] = True
    val_y_mask = torch.zeros(n_samples, dtype=torch.bool)
    val_y_mask[n_tr:n_tr + n_va] = True
    test_y_mask = torch.zeros(n_samples, dtype=torch.bool)
    test_y_mask[n_tr + n_va:] = True

    return Data(x=x, y=torch.tensor(y_reg, dtype=torch.float), y_cls=torch.tensor(y_cls, dtype=torch.long),
                edge_audio_attr=edge_audio_attr, edge_visual_attr=edge_visual_attr, edge_text_attr=edge_text_attr,
                train_y_mask=train_y_mask, val_y_mask=val_y_mask, test_y_mask=test_y_mask,
                train_edge_index=train_edge_index, edge_index=edge_index, input_dims=input_dims,
                missing_mask=torch.tensor(missing))


def load_msa_data(args, missing_rate=None):
    rate = args.missing_rate if missing_rate is None else missing_rate
    with open(args.data_path, 'rb') as f:
        raw = pickle.load(f)
    text_path = getattr(args, 'text_features', None)
    if text_path and str(text_path).lower() != 'none':
        feats_npz = np.load(text_path)
        for s in SPLITS:
            if [str(i) for i in raw[s]['id']] != [str(i) for i in feats_npz[s + '_id']]:
                raise ValueError('{}: sample ids in {} do not match {}'.format(s, text_path, args.data_path))
            raw[s] = dict(raw[s])
            raw[s]['text'] = feats_npz[s].astype(np.float32)
        print('text features: {} ({}-d)'.format(text_path, feats_npz['train'].shape[1]))

    feats_per_split, y_reg, y_cls, sizes = [], [], [], []
    for s in SPLITS:
        feats_per_split.append(pool_split(raw[s], args.pooling))
        r, c = get_labels(raw[s])
        y_reg.append(r)
        y_cls.append(c)
        sizes.append(len(r))
    feats = [np.concatenate([fs[j] for fs in feats_per_split], axis=0) for j in range(len(MODALITIES))]
    y_reg = np.concatenate(y_reg)
    y_cls = np.concatenate(y_cls)
    n_samples = sum(sizes)

    missing = np.zeros((n_samples, len(MODALITIES)), dtype=bool)
    if rate > 0:
        # which splits receive missing modalities
        if args.missing_splits == 'all':
            rows = np.arange(n_samples)
        elif args.missing_splits == 'eval':
            rows = np.arange(sizes[0], n_samples)
        elif args.missing_splits == 'test':
            rows = np.arange(sizes[0] + sizes[1], n_samples)
        else:
            raise ValueError('unknown --missing_splits {}'.format(args.missing_splits))
        missing[rows] = make_missing_mask(len(rows), len(MODALITIES), rate, args.missing_seed,
                                          args.min_available, args.keep_mode)

    print('{}: train/valid/test = {}/{}/{}, dims (audio, visual, text) = {}'.format(
        args.domain, sizes[0], sizes[1], sizes[2], tuple(f.shape[1] for f in feats)))
    print('missing rate {} ({}, splits={}, min_available={}{}): missing per modality = {}, effective rate {:.3f}'.format(
        rate, args.missing_mode, args.missing_splits, args.min_available,
        ', ' + args.keep_mode if args.min_available else '', missing.sum(0).tolist(),
        missing.mean() if rate > 0 else 0.0))
    if rate > 0:
        n_lost = np.bincount(missing.sum(1), minlength=len(MODALITIES) + 1)
        print('samples missing 0/1/2/3 modalities: {}'.format(n_lost.tolist()))
    return build_graph(feats, y_reg, y_cls, sizes, missing, args.missing_mode, args.node_mode)
