# -*- coding: utf-8 -*-
import argparse

DATASET_DEFAULTS = {
    'mosi': ('./datasets/MOSI/aligned_50.pkl', './text_features/mosi_text_features.npz'),
    'mosei': ('./datasets/MOSEI/aligned_50.pkl', './text_features/mosei_text_features.npz'),
}


def build_parser():
    p = argparse.ArgumentParser()
    p.add_argument('--model_types', type=str, default='EGSAGE_EGSAGE')  # L = 2 layers
    p.add_argument('--post_hiddens', type=str, default=None)
    p.add_argument('--concat_states', action='store_true', default=False)
    p.add_argument('--norm_embs', type=str, default=None)
    p.add_argument('--aggr', type=str, default='mean')
    p.add_argument('--node_dim', type=int, default=32)
    p.add_argument('--edge_dim', type=int, default=32)
    p.add_argument('--edge_mode', type=int, default=1)
    p.add_argument('--gnn_activation', type=str, default='relu')
    p.add_argument('--impute_hiddens', type=str, default='')
    p.add_argument('--impute_activation', type=str, default='relu')
    p.add_argument('--impute_out_dim', type=int, default=32)
    p.add_argument('--predict_hiddens', type=str, default='')
    # optimisation
    p.add_argument('--epochs', type=int, default=200)
    p.add_argument('--opt', type=str, default='adam')
    p.add_argument('--opt_scheduler', type=str, default='none')
    p.add_argument('--opt_restart', type=int, default=0)
    p.add_argument('--opt_decay_step', type=int, default=1000)
    p.add_argument('--opt_decay_rate', type=float, default=0.9)
    p.add_argument('--dropout', type=float, default=0.)
    p.add_argument('--weight_decay', type=float, default=0.)
    p.add_argument('--lr', type=float, default=0.001)
    p.add_argument('--known', type=float, default=0.7,
                   help='fraction of edges kept each epoch; in pre-training 1-known is the RME mask ratio r_mask')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--log_dir', type=str, default=None)
    # pre-training (Eq. 9)
    p.add_argument('--lambda1', type=float, default=0.1, help='weight of L_RME')
    p.add_argument('--rme_reduction', type=str, default='sum', choices=['sum', 'mean'],
                   help="GRMI code uses 'sum', which makes L_RME much larger than L_ECL / L_ENM")
    # fine-tuning (Eq. 10)
    p.add_argument('--pretrain_path', type=str, default=None, help="default: ./runs/<domain>/pretrain/model.pt; 'none' = no pre-training")
    p.add_argument('--loss', type=str, default='mse', choices=['mse', 'l1'])
    p.add_argument('--lambda2', type=float, default=0.1, help='weight of L_SEM; 0 disables the SEM')
    p.add_argument('--tau', type=float, default=0.3, help='SEM temperature (not given in the paper)')
    p.add_argument('--sem_hidden', type=int, default=32, help='hidden size of the SEM MLP (0 = linear)')
    p.add_argument('--sem_dim', type=int, default=32, help='output size of the SEM MLP')
    p.add_argument('--sem_normalize', type=int, default=1, help='L2-normalise SEM outputs (cosine similarity)')
    p.add_argument('--sem_labels', type=str, default='cls3', choices=['cls3', 'binary'],
                   help='cls3: negative/neutral/positive; binary: negative vs non-negative')
    # memory: contrastive losses on a random subset of samples
    p.add_argument('--contrast_batch', type=int, default=None,
                   help='compute the edge contrastive / edge-node matching (pre-training) and SEM (fine-tuning) losses on a '
                        'random subset of this many samples each epoch; 0 = all samples. Default: 0 for MOSI, 8192 for MOSEI '
                        '(the full n x n matrices of MOSEI need ~40-50 GB of GPU memory)')
    # missing modalities
    p.add_argument('--missing_rate', type=float, default=0.0)
    p.add_argument('--missing_mode', type=str, default='zero', choices=['zero', 'drop'])
    p.add_argument('--missing_splits', type=str, default='all', choices=['all', 'eval', 'test'])
    p.add_argument('--missing_seed', type=int, default=0)
    p.add_argument('--min_available', type=int, default=0, choices=[0, 1, 2],
                   help='minimum number of modalities every sample keeps (0 = no constraint)')
    p.add_argument('--keep_mode', type=str, default='swap', choices=['swap', 'restore'],
                   help='swap: exact per-modality rate (capped at 2/3 with min_available=1); restore: give one modality back, rate drops')
    # evaluation
    p.add_argument('--neutral_band', type=float, default=0.5,
                   help="'sign' scheme: a prediction p is neutral if |p| <= band (0.5 = round to nearest integer)")
    p.add_argument('--select_metric', type=str, default='acc2_non0',
                   help='validation metric that picks the reported epoch (final setting: acc2_non0 = Non0 Acc-2); also '
                        'sign_acc3, sign_f1, mmsa_acc3, mmsa_f1, has0_acc2, has0_f1, non0_f1, mae, corr')

    sub = p.add_subparsers(dest='domain')
    sub.required = True
    for name, (path, text_path) in DATASET_DEFAULTS.items():
        sp = sub.add_parser(name)
        sp.add_argument('--data_path', type=str, default=path, help='MMSA aligned_50.pkl')
        sp.add_argument('--text_features', type=str, default=text_path,
                        help="utterance-level text features (.npz) that replace the file's text; 'none' = use the file's own text")
        sp.add_argument('--pooling', type=str, default='mask', choices=['mask', 'mean'],
                        help='mask: mean over real tokens (attention mask from text_bert); mean: over all T steps')
        sp.add_argument('--edge_input_dim', type=int, default=64)
        sp.add_argument('--n_modalities', type=int, default=3)
        sp.add_argument('--output_activation', type=str, default=None)
        sp.add_argument('--predict_out_dim', type=int, default=1)
        sp.add_argument('--node_mode', type=int, default=0)
    return p


def finalize_args(args):
    """Fill in defaults that depend on the dataset."""
    if getattr(args, 'contrast_batch', None) is None:
        args.contrast_batch = 8192 if args.domain == 'mosei' else 0
    return args


def parse_args(argv=None):
    return finalize_args(build_parser().parse_args(argv))
