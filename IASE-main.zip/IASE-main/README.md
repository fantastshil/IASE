# IASE

PyTorch implementation of "Information Aggregate and Sentiment Enhance Network to Handle Missing Modalities for
Multimodal Sentiment Analysis" (IEEE ICME 2024).

IASE models a multimodal dataset as a bipartite graph: every utterance is a sample node, audio / visual / text are
modality nodes, and each (sample, modality) edge carries that modality's features. An edge-aware
Information Aggregation Module (IAM) shares complementary information across samples and modalities. The IAM is
pre-trained with three tasks (edge contrastive learning, edge-node matching, reconstruction of masked edges); during
fine-tuning a Sentiment Enhance Module (SEM) adds a supervised contrastive loss that keeps samples of different
sentiment apart.



## Installation


```bash
conda create -n iase python=3.10 -y
conda activate iase
pip install torch==2.3.1 --index-url https://download.pytorch.org/whl/cu121
pip install -r requirements.txt
```

## Data

Download the aligned CMU-MOSI and CMU-MOSEI files of the [MMSA toolkit](https://github.com/thuiar/MMSA) and place
them as `datasets/MOSI/aligned_50.pkl` and `datasets/MOSEI/aligned_50.pkl`. Audio, visual features and labels come
from these files; the text features are provided in : Text_feature: https://pan.baidu.com/s/1ngUvNZGJ2wUfSdyZXPmrmg?pwd=6i3g code: 6i3g, and put them into `text_features/`.

## Running



```bash
python run.py mosi        # or: bash scripts/run_mosi.sh
python run.py mosei       # or: bash scripts/run_mosei.sh
```

`run.py` pre-trains the IAM (`runs/<dataset>/pretrain/model.pt`), fine-tunes IASE with seeds 0, 1, 2
(`runs/<dataset>/full_seed<k>/`: `result.pkl` with per-epoch validation/test metrics, `model.pt`) and prints the
mean ± standard deviation of the test metrics. The reported test result of each run is the one at the epoch with the
best validation Non0 Acc-2. Single steps:

```bash
python pretrain.py mosi
python train.py --seed 0 mosi
```



## Results

Mean over seeds 0, 1, 2. Acc-2 / F1 follow the MMSA definitions: **Non0** = negative vs. positive with
neutral samples excluded, F1 is support-weighted.

| Dataset | Non0 Acc-2 | Non0 F1 |
|---|---|---|
| CMU-MOSI | 84.40 | 84.24 |
| CMU-MOSEI | 86.47 | 86.49 |

Results may differ slightly with hardware and library versions.



## Citation

```bibtex
@inproceedings{shi2024iase,
  title     = {Information Aggregate and Sentiment Enhance Network to Handle Missing Modalities for Multimodal Sentiment Analysis},
  author    = {Shi, Liang and Xu, Fuyong and Wang, Ru and Wei, Yongqing and Wang, Guangjin and Wang, Bao and Liu, Peiyu},
  booktitle = {2024 IEEE International Conference on Multimedia and Expo (ICME)},
  year      = {2024},
  doi       = {10.1109/ICME57554.2024.10687981}
}
```
