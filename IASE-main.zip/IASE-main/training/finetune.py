# -*- coding: utf-8 -*-
import copy
import pickle

import numpy as np
import torch

from models.iam import Multmodality
from models.sem import SentimentEnhanceModule
from utils.metrics import msa_metrics, LOWER_IS_BETTER
from utils.utils import build_optimizer, get_known_mask


def _fmt(m):
    return 'acc3 {:.4f} f1 {:.4f} | mmsa acc3 {:.4f} f1 {:.4f} | has0 acc2 {:.4f} f1 {:.4f} | non0 acc2 {:.4f} f1 {:.4f} | mae {:.4f} corr {:.4f}'.format(
        m['sign_acc3'], m['sign_f1'], m['mmsa_acc3'], m['mmsa_f1'], m['has0_acc2'], m['has0_f1'],
        m['acc2_non0'], m['non0_f1'], m['mae'], m['corr'])


def train_iase(data, args, log_path, device=torch.device('cpu')):
    model = Multmodality(data, args).to(device)
    if args.pretrain_path and args.pretrain_path.lower() != 'none':
        model.load_state_dict(torch.load(args.pretrain_path, map_location=device))
        print('loaded pre-trained information aggregation module from', args.pretrain_path)
    else:
        print('no pre-training: information aggregation module trained from scratch')

    trainable_parameters = list(model.parameters())
    sem = None
    if args.lambda2 > 0:
        sem = SentimentEnhanceModule(args.node_dim, args.sem_hidden, args.sem_dim, args.tau,
                                     bool(args.sem_normalize), args.dropout).to(device)
        trainable_parameters += list(sem.parameters())
    scheduler, opt = build_optimizer(args, trainable_parameters)
    criterion = torch.nn.MSELoss() if args.loss == 'mse' else torch.nn.L1Loss()

    n_row = data.y.shape[0]
    x = data.x.to(device)
    y = data.y.to(device)
    y_cls = data.y_cls.to(device)
    sem_labels = y_cls if args.sem_labels == 'cls3' else (y >= 0).long()
    edge_index = data.edge_index.to(device)
    train_edge_index = data.train_edge_index.to(device)
    edge_audio_attr = data.edge_audio_attr.to(device)
    edge_visual_attr = data.edge_visual_attr.to(device)
    edge_text_attr = data.edge_text_attr.to(device)
    train_y_mask = data.train_y_mask.to(device)
    val_y_mask = data.val_y_mask.to(device)
    test_y_mask = data.test_y_mask.to(device)
    train_idx = torch.where(train_y_mask)[0]
    n_train = int(train_idx.numel())
    if 0 < getattr(args, 'contrast_batch', 0) < n_train:
        print('SEM on random subsets of {} of {} training samples'.format(args.contrast_batch, n_train))
    y_np, y_cls_np = data.y.numpy(), data.y_cls.numpy()
    val_np, test_np = data.val_y_mask.numpy(), data.test_y_mask.numpy()

    print('train {}, valid {}, test {} samples'.format(int(train_y_mask.sum()), int(val_y_mask.sum()), int(test_y_mask.sum())))

    curves = {'train_loss': [], 'train_sc': [], 'train_sem': [], 'valid': [], 'test': []}
    lower = args.select_metric in LOWER_IS_BETTER
    best = {'score': None, 'epoch': -1}

    for epoch in range(args.epochs):
        model.train()
        if sem is not None:
            sem.train()
        a_n, v_n, t_n = edge_audio_attr.shape[0] // 2, edge_visual_attr.shape[0] // 2, edge_text_attr.shape[0] // 2
        audio_mask = get_known_mask(1 - args.known, a_n).to(device)
        visual_mask = get_known_mask(1 - args.known, v_n).to(device)
        text_mask = get_known_mask(1 - args.known, t_n).to(device)
        all_mask = torch.cat((audio_mask, audio_mask, visual_mask, visual_mask, text_mask, text_mask), dim=0)

        opt.zero_grad()
        _, node_embedding, _, pred = model(x,
                                           edge_audio_attr[~torch.cat((audio_mask, audio_mask))],
                                           edge_visual_attr[~torch.cat((visual_mask, visual_mask))],
                                           edge_text_attr[~torch.cat((text_mask, text_mask))],
                                           train_edge_index[:, ~all_mask], edge_index)
        pred = pred.view(-1)
        loss_sc = criterion(pred[train_y_mask], y[train_y_mask])
        if sem is not None:
            if 0 < args.contrast_batch < n_train:
                sub = train_idx[torch.randperm(n_train, device=device)[:args.contrast_batch]]
                loss_sem = sem(node_embedding[sub], sem_labels[sub])
            else:
                loss_sem = sem(node_embedding[:n_row][train_y_mask], sem_labels[train_y_mask])
            loss = loss_sc + args.lambda2 * loss_sem
        else:
            loss_sem = torch.zeros(())
            loss = loss_sc
        loss.backward()
        opt.step()
        if scheduler is not None:
            scheduler.step()
        curves['train_loss'].append(loss.item())
        curves['train_sc'].append(loss_sc.item())
        curves['train_sem'].append(loss_sem.item())

        model.eval()
        with torch.no_grad():
            _, _, _, pred = model(x, edge_audio_attr, edge_visual_attr, edge_text_attr, train_edge_index, edge_index)
            pred_np = pred.view(-1).cpu().numpy()
        m_val = msa_metrics(pred_np[val_np], y_np[val_np], y_cls_np[val_np], args.neutral_band)
        m_test = msa_metrics(pred_np[test_np], y_np[test_np], y_cls_np[test_np], args.neutral_band)
        curves['valid'].append(m_val)
        curves['test'].append(m_test)

        score = m_val[args.select_metric]
        if best['score'] is None or (score < best['score'] if lower else score > best['score']):
            best = {'score': score, 'epoch': epoch, 'valid': m_val, 'test': m_test,
                    'pred_test': pred_np[test_np].copy(),
                    'model': copy.deepcopy(model.state_dict()),
                    'sem': copy.deepcopy(sem.state_dict()) if sem is not None else None}

        if epoch % 20 == 0 or epoch == args.epochs - 1:
            print('epoch {:4d} loss {:.4f} (sc {:.4f}, sem {:.4f}) | valid {} | test {}'.format(
                epoch, loss.item(), loss_sc.item(), loss_sem.item(), _fmt(m_val), _fmt(m_test)))

    print('best valid {} = {:.4f} at epoch {}'.format(args.select_metric, best['score'], best['epoch']))
    print('TEST @ best valid: ' + _fmt(best['test']))

    torch.save({'model': best['model'], 'sem': best['sem'], 'epoch': best['epoch']}, log_path + 'model.pt')
    obj = {'args': args, 'curves': curves, 'best_epoch': best['epoch'],
           'best_valid': best['valid'], 'best_test': best['test'],
           'outputs': {'pred_test': best['pred_test'], 'label_test': y_np[test_np], 'label_cls_test': y_cls_np[test_np]}}
    with open(log_path + 'result.pkl', 'wb') as f:
        pickle.dump(obj, f)
    return obj
